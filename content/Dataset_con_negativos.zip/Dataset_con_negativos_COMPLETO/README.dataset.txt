# FEDAPUR_Stamps > 2025-11-30 4:52pm
https://universe.roboflow.com/dataset-fedapur/fedapur_stamps-byo6r

Provided by a Roboflow user
License: CC BY 4.0

